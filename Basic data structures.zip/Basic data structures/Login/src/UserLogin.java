import java.util.Scanner;

public class UserLogin {
	
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter User name :");
		String UserName=sc.nextLine();
		System.out.println("Enter Password");
		String Password=sc.nextLine();
		if(UserName.equals("shiva") && Password.equals("Jayanth")) {
			System.out.println("Welcome");
		}
		else {
			for(int i=1;i<=3;i++) {
				System.out.println("Reattempt time :"+i);
				System.out.println("Enter User name :");
				String UserName1=sc.nextLine();
				System.out.println("Enter Password");
				String Password1=sc.nextLine();
				if(UserName1.equals("shiva") && Password1.equals("Jayanth")) {
					System.out.println("Welcome");
					break;
			}
				else {
					System.out.println("Contact Admin");
				}
		}
	
	}

}
}