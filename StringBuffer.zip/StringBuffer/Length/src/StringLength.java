public class StringLength {
	public static void main(String[] args) {
		String str = "Hello World";
		System.out.println("Lenght of the String is: " + str.length());
	}
}