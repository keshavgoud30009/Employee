public class JoinStrings {
	public static void main(String[] args) {
		String str1 = "Hello";
		String str2 = "How are you";
		System.out.println(str1 +" "+ str2);
	}
}
