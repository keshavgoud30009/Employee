package Q4;

public class Driver_calss {
public static void main(String[] args) {
	//we cannot instantiate a abstract class
	//Main m=new Main();
}
}
